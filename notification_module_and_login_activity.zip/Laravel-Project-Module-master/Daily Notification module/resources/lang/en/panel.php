<?php

return [
    'site_title' => 'Notifications',
];
